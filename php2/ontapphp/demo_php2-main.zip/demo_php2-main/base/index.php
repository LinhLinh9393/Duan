<?php
session_start();
require_once 'env.php';
require_once 'vendor/autoload.php';
require_once 'commons/route.php';
//require_once 'app/controllers/StudentController.php';
//use App\Controllers\StudentController;
//echo getStudent();
//$st = new StudentController();
//$st->getStudent();

?>